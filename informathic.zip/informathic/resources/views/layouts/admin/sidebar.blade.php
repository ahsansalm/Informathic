
<aside class="left-sidebar bg-sidebar" style="background: #0C1741!important">
          <div id="sidebar" class="sidebar sidebar-with-footer">
            <!-- Aplication Brand -->
            <div class="app-brand" style="background: white !important;">
              <a href="">
                <span class="brand-name">
                  <img src="{{asset('img/logo/logo.png')}}" style="max-width:160px !important;"alt="">
                </span>
                
              </a>
            </div>
            <!-- begin sidebar scrollbar -->
            <div class="sidebar-scrollbar">

              <!-- sidebar menu -->
              <ul class="nav sidebar-inner" id="sidebar-menu" style="margin-top: 0px !important;">
                

                
                  <!-- problems of users -->
                  <?php $role = Auth::user()->role_as; ?>
                  @if($role == 1)
                  <li  class="has-sub {{ Request::is('home') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/home')}}" >
                    <i class="fa fa-user" style="font-size:24px"></i>
                      <span class="nav-text">Tous les utilisateurs</span> 
                    </a>
                  </li>
                  <li  class="has-sub active colorBack" >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Problèmes utilisateur</span> 
                    </a>
                  </li> 
                  <li  class="has-sub {{ Request::is('problem') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/problem')}}" >
                    <i class="fa fa-question-circle" style="font-size:24px"></i>
                      <span class="nav-text">Problèmes</span> 
                    </a>
                  </li>
                  <li  class="has-sub active colorBack" >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Ordres</span> 
                    </a>
                  </li> 
                  <li  class="has-sub {{ Request::is('userOrder') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/userOrder')}}" >
                    <i class="fa fa-suitcase" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Toutes les commandes</span> 
                    </a>
                  </li>
                  <li  class="has-sub active colorBack " >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Devis</span> 
                    </a>
                  </li> 
                  <li  class="has-sub {{ Request::is('userQuotes') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/userQuotes')}}" >
                    <i class="fa fa-book" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Citations d'utilisateurs</span> 
                    </a>
                  </li>

                  @else
                  <!-- dashboard -->
                  <li  class="has-sub {{ Request::is('home') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/home')}}" >
                      <i class="mdi mdi-view-dashboard-outline"></i>
                      <span class="nav-text">Tableau de bord</span> 
                    </a>
                  </li>
                <!-- my account -->
                <li  class="has-sub active colorBack" >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Mon compte</span> 
                    </a>
                  </li>
                <!-- my device -->
                <li  class="has-sub {{ Request::is('MyProfile') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MyProfile')}}" aria-controls="dashboard">
                      <i class="mdi mdi-image-filter-none"></i>
                        <span class="nav-text">Mon information</span> 
                    </a>
                  </li>
                <!-- my devices -->
                <li  class="has-sub {{ Request::is('MyDevices') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MyDevices')}}">
                    <i class="fa fa-desktop" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Mes appareils</span> 
                    </a>
                  </li>
                <!-- send parcel -->
                <li  class="has-sub {{ Request::is('SendParcel') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/SendParcel')}}">
                    <i class="fa fa-envelope" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Envoyer un colis</span> 
                    </a>
                  </li>
                <!-- my document -->
                <li  class="has-sub active colorBack " >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Mon document</span> 
                    </a>
                  </li>
                <!-- my support -->
                <li  class="has-sub {{ Request::is('MySupport') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MySupport')}}">
                    <i class="fa fa-paper-plane-o" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Mon support</span> 
                    </a>
                  </li>
                   <!-- my notification -->
                <li  class="has-sub {{ Request::is('notification') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/notification')}}">
                    <i class="fa fa-bell-o" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Notification</span> 
                    </a>
                  </li>
                <!-- my quotes -->
                <li  class="has-sub {{ Request::is('MyQuotes') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MyQuotes')}}">
                    <i class="fa fa-book" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Mes citations</span> 
                    </a>
                  </li>
                <!-- my bill  -->
                <li  class="has-sub {{ Request::is('MyBill') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MyBill')}}">
                    <i class="fa fa-sticky-note" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Mes factures</span> 
                    </a>
                  </li>
                <!-- my order -->
                
                <li  class="has-sub {{ Request::is('MyOrder') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/MyOrder')}}">
                    <i class="fa fa-suitcase" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Commande non approuvée</span> 
                    </a>
                  </li>
                   <!-- my order approved -->
                
                <li  class="has-sub {{ Request::is('ApprovedOrder') ? 'active':''; }}" >
                    <a class="sidenav-item-link" href="{{url('/ApprovedOrder')}}">
                    <i class="fa fa-check-square" style="font-size:24px;color:white"></i>
                      <span class="nav-text">Commande approuvée</span> 
                    </a>
                  </li>
                <!-- remote support -->
                <!-- <li  class="has-sub active " style="background: rgb(174,203,6,0.4) " >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <span class="nav-text">Assistance à distance</span> 
                    </a>
                  </li> -->
                <!-- support portfolio -->
                <!-- <li  class="has-sub " >
                    <a class="sidenav-item-link" aria-controls="dashboard">
                      <i class="mdi mdi-view-dashboard-outline"></i>
                      <span class="nav-text">Portefeuille de soutien</span> 
                    </a>
                </li> -->
                @endif 


 
                  <hr class="separator" />

            
          </div>
        </aside>