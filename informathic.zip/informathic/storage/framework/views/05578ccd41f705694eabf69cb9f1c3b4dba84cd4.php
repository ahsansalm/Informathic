<p>
    <a
    class="text-primary"
    href="#"
    target="_blank"
    >
    Informathic</a>
    &copy; <span id="copy-year">2022</span> 
</p><?php /**PATH E:\newXaammpp\htdocs\projects\akitatek\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>