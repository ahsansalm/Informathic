
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="col-12 text-center">
                <div class="dashboard_image" >
                    <h1 class="brand_device mt-5">Voir ma facture</h1> 
                </div>
            </div>
            <div class="card-body">
                    <table class="table mt-2">
                        <thead style="background: rgb(12, 23, 65);">
                            <tr>
                                <th scope="col" class="text-white">#</th>
                                <th scope="col" class="text-white">Titre</th>
                                <th scope="col" class="text-white">Prix ​​total</th>
                                <th scope="col" class="text-white">Date</th>
                                <th scope="col" class="text-white">Statut</th>
                                <th scope="col" class="text-white" style="width: 80px;">Option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><b class="text-dark"><?php echo e($i++); ?></b></th>
                                    <td><?php echo e($invoice->product->product); ?></td>
                                    <td><b class="text-dark"><?php echo e($invoice->totalPrice); ?></b></td>
                                    <td><?php echo e($invoice->date); ?></td>
                                    <?php if($invoice->status =='Approved'): ?>
                                    <td><span class="badge badge-success"><?php echo e($invoice->status); ?></span></td>
                                    <?php else: ?>
                                    <td><span class="badge badge-danger"><?php echo e($invoice->status); ?></span></td>
                                    <?php endif; ?>
                                    <td>
                                            <a href="<?php echo e(url('/Mybill/Detail/'.$invoice->id)); ?>">
                                                <button type="button" class="btn btn-outline-primary btn-sm"><i style="font-size: 16px;" class="fa fa-eye pl-2"></i></button>
                                            </a>
                                            <!-- <div class="btn-group ml-1" role="group">
                                                <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                More Options
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                <a class="dropdown-item text-danger" href=""><i class="fa fa-trash-o"></i>Delete</a>
                                                </div>
                                            </div> -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\project\akitatek\resources\views/bill/index.blade.php ENDPATH**/ ?>