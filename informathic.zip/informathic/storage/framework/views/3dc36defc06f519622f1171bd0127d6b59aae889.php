
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="col-12 text-center">
                <div class="dashboard_image" >
                    <h1 class="brand_device mt-5">Commande de l'utilisateur</h1>
                     
                </div>
            </div>
            <div class="card-body">
                <!-- <h3 class="card-title text-center">Total Orders: <span class="badge bg-primary mr-5"><?php echo e($totalOrder); ?></span> 
                Approved Orders: <span class="badge bg-success mr-5"><?php echo e($approvedOrder); ?></span>
                Pending Orders: <span class="badge bg-danger"><?php echo e($pendingOrder); ?></span></h3> -->
                        <table class="table mt-2">
                            <thead style="background: rgb(12, 23, 65);">
                                <tr>
                                    <th scope="col" class="text-white">#</th>
                                    <th scope="col" class="text-white">Nom d'utilisateur</th>
                                    <th scope="col" class="text-white">Image utilisateur</th>
                                    <th scope="col" class="text-white">Des marques</th>
                                    <th scope="col" class="text-white">Produit</th>
                                    <th scope="col" class="text-white">Demande de service</th>
                                    <th scope="col" class="text-white">Statut</th>
                                    <th scope="col" class="text-white">Prix</th>
                                    <th scope="col" class="text-white">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form>
                                        <tr>
                                            <th scope="row"><b class="text-dark"><?php echo e($i++); ?></b></th>
                                            <th scope="row" hidden><b class="text-dark"><?php echo e($device->id); ?></b></th>
                                            <td><b><?php echo e($device->user->firstname); ?> <?php echo e($device->user->lastname); ?> </b></td>
                                            <td><img src="<?php echo e($device->user->photo); ?>  " style="height: 30px; width 20px;" alt=""></td>
                                            <td><b class="text-dark"><?php echo e($device->product->marks); ?></b></td>
                                            <td><?php echo e($device->product->product); ?></td>
                                            <td><?php echo e($device->product->serviceRequest); ?></td>
                                            <?php if($device->product->status =='Approved'): ?>
                                            <td><span class="badge bagde-sm bg-success"><?php echo e($device->product->status); ?></span></td>
                                            <?php else: ?>
                                            <td><span class="badge bagde-sm bg-danger"><?php echo e($device->product->status); ?></span></td>
                                            <?php endif; ?>
                                            <td><?php echo e($device->totalPrice); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('Approved/order/detail/'.$device->productId)); ?>">
                                                    <button type="button" class="btn btn-sm btn-primary">Voir</button>
                                                </a>
                                            </td>
                                        </tr>
                                    </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\project\akitatek\resources\views/order/userOrder.blade.php ENDPATH**/ ?>