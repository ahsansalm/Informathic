<header class="main-header " id="header">
    <nav class="navbar navbar-static-top navbar-expand-lg">
        <!-- Sidebar toggle button -->
        <button id="sidebar-toggler" class="sidebar-toggle">
        <span class="sr-only">Toggle navigation</span>
        </button>
        <!-- search form -->
        <div class="search-form d-none d-lg-inline-block">
        <div class="input-group">
            <button type="button" name="search" id="search-btn" class="btn btn-flat">
            </button>
        </div>
        <div id="search-results-container">
            <ul id="search-results"></ul>
        </div>
        </div>

        <div class="navbar-right ">

        <ul class="nav navbar-nav">

        


        

            <!-- User Account -->
            <li class="dropdown user-menu">
            <button href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <span class="d-none d-lg-inline-block"><?php echo e(auth()->user()->name); ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-right">
                <!-- User image -->
                <li class="dropdown-header">
                <img src="<?php echo e(auth()->user()->profile->photo); ?>"style="height:50px;" class="img-circle" alt="User Image" />
                <div class="d-inline-block">
                <?php echo e(auth()->user()->name); ?> <small class="pt-1"><?php echo e(auth()->user()->email); ?></small>
                </div>
                </li>

                <li>
                <a href="<?php echo e(url('/MyProfile')); ?>">
                    <i class="mdi mdi-account"></i> Mon profil
                </a>
                </li>

                <li class="dropdown-footer">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <i class="mdi mdi-logout"></i>
                        <?php echo e(__('Se déconnecter')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
            </li>
        </ul>
        </div>
    </nav>
</header><?php /**PATH E:\xamp\htdocs\project\akitatek\resources\views/layouts/admin/navbar.blade.php ENDPATH**/ ?>