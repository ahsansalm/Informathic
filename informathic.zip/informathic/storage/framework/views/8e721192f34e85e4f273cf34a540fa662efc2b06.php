
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="col-12 text-center">
                <div class="dashboard_image" >
                    <h1 class="brand_device mt-5">Voir mes devis actifs</h1> 
                </div>
            </div>
            <div class="card-body">
                    <table class="table mt-2">
                        <thead style="background: rgb(12, 23, 65);">
                            <tr>
                                <th scope="col" class="text-white">#</th>
                                <th scope="col" class="text-white">Des marques</th>
                                <th scope="col" class="text-white">Produit</th>
                                <th scope="col" class="text-white">Demande de service</th>
                                <th scope="col" class="text-white">Statut</th>
                                <th scope="col" class="text-white">Prix</th>
                                <th scope="col" class="text-white" style="width: 80px;">Option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                                <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form action="<?php echo e(url('/quotes/value/'.$device->id)); ?>" method='POST'>
                                        <?php echo csrf_field(); ?>
                                        <tr>
                                            <th scope="row"><b class="text-dark"><?php echo e($i++); ?></b></th>
                                            <td><b class="text-dark"><?php echo e($device->product->marks); ?></b></td>
                                            <td><?php echo e($device->product->product); ?></td>
                                            <td><?php echo e($device->product->serviceRequest); ?></td>
                                            <?php if($device->status =='Approved'): ?>
                                            <td><span class="badge bagde-sm bg-success"><?php echo e($device->status); ?></span></td>
                                            <?php else: ?>
                                            <td><span class="badge bagde-sm bg-danger"><?php echo e($device->status); ?></span></td>
                                            <?php endif; ?>
                                            <td><b><?php echo e($device->quotePrice); ?></b></td>
                                            <td hidden><input type="text" value="<?php echo e($device->quotePrice); ?>" name="Price"><?php echo e($device->quotePrice); ?></td>
                                            <td>
                                                <button type="submit" class="btn btn-sm btn-primary">Ordre</button>
                                            </td>
                                        </tr>
                                    </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\informathic\informathic\resources\views/quotes/index.blade.php ENDPATH**/ ?>