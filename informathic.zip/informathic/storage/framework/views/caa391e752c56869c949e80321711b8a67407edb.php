
<?php $__env->startSection('content'); ?>
<div class="bg-white border rounded">
    <div class="row no-gutters">
        <div class="col-lg-4 col-xl-3">
            <div class="profile-content-left pt-5 pb-3 px-3 px-xl-5">
                
                <div class="contact-info pt-4">
                    <h5 class="text-dark mb-1">Coordonnées</h5>
                <hr class="w-100">
            <form action="<?php echo e(URL('profile/update/')); ?>/<?php echo e(auth()->user()->id); ?>" method="POST" enctype="multipart/form-data"  >
                <?php echo csrf_field(); ?>
                    <p class="text-dark font-weight-medium pt-4 mb-2">Adresse e-mail</p>
                    <input type="text" class="form-control" id="inputPassword" name="email" value="<?php echo e(auth()->user()->email); ?>">
                    <p class="text-dark font-weight-medium pt-4 mb-2">Numéro de téléphone</p>
                    <input type="number" class="form-control" id="inputPassword" name="phone" value="<?php echo e(auth()->user()->profile->phone); ?>">
                    <p class="text-dark font-weight-medium pt-4 mb-2">Adresse postale</p>
                    <input type="text" class="form-control" id="inputPassword" name="postal" value="<?php echo e(auth()->user()->profile->postal); ?>">
                    <p class="text-dark font-weight-medium pt-4 mb-2">adresse permanente</p>
                    <input type="text" class="form-control" id="inputPassword" name="address" value="<?php echo e(auth()->user()->profile->address); ?>">
                </div>
            </div>
        </div>
        <div class="col-lg-8 col-xl-9">
            <div class="profile-content-right">
                <div class="dashboard_image">
                    <h1 class="brand_device mt-5 text-center">Editer le profil</h1> 
                </div>    
                <br>            
                <h5 class="text-dark mb-1 ml-3">Renseignements personnels</h5>
                <hr class="w-100">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group row ml-2">
                            <label for="staticEmail" class="col-sm-4 col-form-label text-dark font-weight-medium">Prénom:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="inputPassword" name="firstname" value="<?php echo e(auth()->user()->name); ?>">
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                <label for="inputPassword" class="col-sm-4 col-form-label text-dark font-weight-medium">Nom de famille:</label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="inputPassword" name="lastname" value="<?php echo e(auth()->user()->profile->lastname); ?>">
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                <label for="inputPassword" class="col-sm-4 col-form-label text-dark font-weight-medium">Ville: </label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="inputPassword" name="town" value="<?php echo e(auth()->user()->profile->town); ?>">
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                <label for="inputPassword" class="col-sm-4 col-form-label text-dark font-weight-medium">Code postal: </label>
                                <div class="col-md-8">
                                    <input type="number" class="form-control" id="inputPassword" name="code" value="<?php echo e(auth()->user()->profile->code); ?>">
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                <label for="inputPassword" class="col-sm-4 col-form-label text-dark font-weight-medium">Changer la photo:</label>
                                <div class="col-md-8">
                                    <input type="hidden" name="old_image" value="<?php echo e(auth()->user()->profile->photo); ?>">
                                    <input type="file"  name="photo" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row ml-2">
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-block next-step">Mise à jour</button>
                                    </div>                                
                            </div>
                        </div>
                        <div class="col-md-3">
                            <img src="<?php echo e(auth()->user()->profile->photo); ?>"style="height: 200px; width: 200px;" alt="">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\project\akitatek\resources\views/profile/index.blade.php ENDPATH**/ ?>