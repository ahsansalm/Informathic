
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="col-12 text-center">
                <div class="dashboard_image">
                    <h1 class="brand_device mt-5">Notification</h1> 
                </div>
            </div>
            <div class="card-body">
                    <table class="table mt-2">
                        <thead style="background: rgb(12, 23, 65);">
                            <tr>
                                <th scope="col" class="text-white">#</th>
                                <th scope="col" class="text-white">Des marques</th>
                                <th scope="col" class="text-white">Produit</th>
                                <th scope="col" class="text-white">bénéficier à</th>
                                <th scope="col" class="text-white" >Icône</th>
                                <th scope="col" class="text-white" >Statut</th>
                                <th scope="col" class="text-white" >Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                                <?php $__currentLoopData = $ProblemReply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><b class="text-dark"><?php echo e($i++); ?></b></th>
                                        <td><b class="text-dark"><?php echo e($device->product->marks); ?></b></td>
                                        <td><?php echo e($device->product->product); ?></td>
                                        <td><?php echo e($device->product->serviceRequest); ?></td>
                                        <td><?php echo e($device->icon); ?></td>
                                        <?php if($device->status =='new'): ?>
                                        <td><span class="badge bg-danger"><?php echo e($device->status); ?></span></td>    
                                        <?php else: ?>
                                        <td><span class="badge bg-success"><?php echo e($device->status); ?></span></td>    
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(url('/notification/detail/'.$device->id)); ?>">
                                                <button type="button" class="btn btn-primary btn-sm">Suite</button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\informathic\informathic\resources\views/notification/index.blade.php ENDPATH**/ ?>