
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">  
        <form action="<?php echo e(url('/order/approved/'.$device->id)); ?>" method='POST'>
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="dashboard_image">
                    <h1 class="text-center mt-5">Détail de la commande de l’utilisateur</h1> </button>
                        </a>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead class="thead-custom">
                        <tr >
                            <th class="text-white" scope="col">#</th>
                            <th class="text-white" scope="col">Données utilisateur</th>
                            <th class="text-white" scope="col">Informations</th>
                            </tr>
                        </thead>
                        <tbody class="text-dark">
                            <tr>
                            <th scope="row">1</th>
                            <td><h6>Nom d’utilisateur :</h6></td>
                            <td><p><?php echo e($device->user->firstname); ?> <?php echo e($device->user->lastname); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">2</th>
                            <td><h6>E-mail de l’utilisateur:</h6></td>
                            <td><p><?php echo e($device->register->email); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">3</th>
                            <td><h6>Adresse :</h6></td>
                            <td><p><?php echo e($device->user->address); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">4</th>
                            <td><h6>Code postal :</h6></td>
                            <td><p><?php echo e($device->user->postal); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">5</th>
                            <td><h6>Numéro de téléphone :</h6></td>
                            <td><p><?php echo e($device->user->phone); ?></p></td>
                            </tr>
                        </tbody>
                    </table>



                    <table class="table">
                        <thead class="thead-custom">
                        <tr >
                            <th class="text-white" scope="col">#</th>
                            <th class="text-white" scope="col">Données produit</th>
                            <th class="text-white" scope="col">Informations</th>
                            </tr>
                        </thead>
                        <tbody class="text-dark">
                            <tr>
                            <th scope="row">1</th>
                            <td hidden id="userId"><?php echo e($device->id); ?></td>
                            <td><h6>Marques :</h6></td>
                            <td><p><?php echo e($device->marks); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">2</th>
                            <td><h6>Produit:</h6></td>
                            <td><p><?php echo e($device->product); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">3</th>
                            <td><h6>Demande de service :</h6></td>
                            <td><p><?php echo e($device->serviceRequest); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">4</th>
                            <td><h6>Commandez par l’intermédiaire de:</h6></td>
                            <td><p><?php echo e($device->shipment); ?></p></td>
                            </tr>
                            <tr>
                            <th scope="row">5</th>
                            <td><h6>Prix :</h6></td>
                            <td><p><?php echo e($device->parcel->totalPrice); ?></p></td>
                            </tr>
                            <tr>
                        </tbody>
                    </table>
                

                        <div class="row">
                            <div class="col-md-4">
                                <a href="<?php echo e(url('/userOrder')); ?>">
                                    <button type="button" class="default-btn prev-step btn-block btn-secondary">Retour</button>
                                </a>
                            </div>

                            <div class="col-md-4">
                                <button type="button" class="default-btn next-step  btn-block btn-primary" id="refuse" >Refuser</button>
                            </div>

                            <div class="col-md-4">
                                <button type="submit" class="default-btn next-step  btn-block btn-primary">Approved</button>
                            </div>

                            
                        </div>

                
            </div>
        
        </form>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
$(document).ready(function(){
    // data submit using ajax
    $("#refuse").click(function () {
        var userId = $("#userId").text();
        console.log(userId)
        $.ajax({
                    url: '<?php echo e(url('/order/refuse')); ?>',
                    type:'post',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    data:{'userId':userId},
                        success:function(success){   
                            if(success){
                                toastr.success(success.message,'Refus de commande!');
                                window.location.href = '/userOrder';
                                
                            }              
                        }           
        }); 
    }); 
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.informathic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\informathic\informathic\resources\views/order/approvedOrderDetail.blade.php ENDPATH**/ ?>